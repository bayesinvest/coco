import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { products } from '../stripe-config';
import { ProductCard } from '../components/ProductCard';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { Heart, Timer, Award, MapPin, Mail, Clock } from 'lucide-react';

export function Home() {
  return (
    <div className="min-h-screen bg-primary">
      <Header />
      <main>
        {/* Hero Section */}
        <section id="home" className="hero-section w-full relative">
          <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/90 to-transparent"></div>
          <div className="container mx-auto px-4 py-32 md:py-40 relative">
            <div className="max-w-xl">
              <span className="inline-block px-4 py-1 bg-coconut text-secondary rounded-full mb-4 font-medium">
                Authentic Dominican Dessert
              </span>
              <h1 className="heading-font text-4xl md:text-5xl lg:text-6xl font-bold text-secondary mb-6">
                Dulce de Coco Horneado
              </h1>
              <p className="text-lg md:text-xl text-secondary/90 mb-8">
                Experience the authentic taste of our traditional Dominican baked coconut dessert, 
                crafted with family recipes passed down through generations.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href="#products"
                  className="bg-accent text-white px-8 py-3 rounded-button font-medium hover:bg-opacity-90 transition-colors text-center"
                >
                  Explore Our Products
                </a>
                <a
                  href="#story"
                  className="border-2 border-secondary text-secondary px-8 py-3 rounded-button font-medium hover:bg-secondary hover:text-primary transition-colors text-center"
                >
                  Our Story
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Our Story Section */}
        <section id="story" className="py-20 bg-coconut/30">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row items-center gap-12">
              <div className="lg:w-1/2">
                <span className="inline-block px-4 py-1 bg-accent text-white rounded-full mb-4 font-medium">
                  Our Story
                </span>
                <h2 className="heading-font text-3xl md:text-4xl font-bold text-secondary mb-6">
                  A Sweet Journey from Dominican Republic to Your Table
                </h2>
                <p className="text-secondary/80 mb-6">
                  Pasión Mechy began in the warm kitchen of Abuela Mercedes in Santo Domingo 15 years ago. 
                  What started as a beloved recipe shared with neighbors quickly gained popularity throughout 
                  the country. Her special Dulce de Coco recipe became a sensation, first in local markets 
                  and then in prestigious restaurants and supermarkets across the Dominican Republic.
                </p>
                <p className="text-secondary/80 mb-6">
                  Today, Paula, my granddaughter, and I have brought this cherished tradition to the United States, 
                  continuing Abuela Mercedes' legacy of excellence and authentic Dominican flavors. Each batch is 
                  still handcrafted with the same love and attention that made her creations famous back home.
                </p>
                <div className="grid grid-cols-3 gap-6 mb-8">
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-3 flex items-center justify-center bg-secondary rounded-full">
                      <Heart className="text-primary w-8 h-8" />
                    </div>
                    <h4 className="font-bold text-secondary">Made with Love</h4>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-3 flex items-center justify-center bg-secondary rounded-full">
                      <Timer className="text-primary w-8 h-8" />
                    </div>
                    <h4 className="font-bold text-secondary">Slow Baked</h4>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-3 flex items-center justify-center bg-secondary rounded-full">
                      <Award className="text-primary w-8 h-8" />
                    </div>
                    <h4 className="font-bold text-secondary">Family Recipe</h4>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div>
                    <p className="italic text-secondary/80">"Every coconut dessert carries a piece of our Dominican heritage and family love."</p>
                    <p className="font-bold text-secondary mt-2">- Abuela Mechy</p>
                  </div>
                </div>
              </div>
              <div className="lg:w-1/2">
                <div className="relative">
                  <img
                    src="https://images.pexels.com/photos/32115433/pexels-photo-32115433.jpeg"
                    alt="Traditional Dominican cooking scene"
                    className="w-full rounded-lg shadow-xl"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Products Section */}
        <section id="products" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block px-4 py-1 bg-coconut text-secondary rounded-full mb-4 font-medium">
                Our Products
              </span>
              <h2 className="heading-font text-3xl md:text-4xl font-bold text-secondary mb-4">
                Dessert
              </h2>
              <p className="max-w-2xl mx-auto text-secondary/80">
                Handcrafted with love using traditional Dominican recipes and the finest coconut.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
              {Object.entries(products).map(([id, product]) => (
                <ProductCard
                  key={id}
                  productId={id as keyof typeof products}
                  {...product}
                  isBundle={id === 'dulce-de-coco-bundle'}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Order Now Section */}
        <section id="order" className="py-20 bg-coconut/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block px-4 py-1 bg-accent text-white rounded-full mb-4 font-medium">
                Order Now
              </span>
              <h2 className="heading-font text-3xl md:text-4xl font-bold text-secondary mb-4">
                Bring Dominican Sweetness Home
              </h2>
              <p className="max-w-2xl mx-auto text-secondary/80">
                Order our authentic Dulce de Coco for yourself or as a special gift for someone you love.
              </p>
            </div>
            <div className="bg-primary rounded-lg shadow-lg p-6 md:p-8 max-w-4xl mx-auto">
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/2">
                  <h3 className="heading-font text-2xl font-bold text-secondary mb-6">Your Order</h3>
                  <div className="mb-6">
                    <p className="text-lg font-medium text-secondary mb-2">Classic Dulce de Coco - $12.99</p>
                    <p className="text-secondary/80 text-sm mb-4">Our traditional Dominican coconut dessert</p>
                  </div>
                  <div className="mb-6">
                    <label className="block text-secondary font-medium mb-2">Quantity</label>
                    <div className="flex border border-secondary/30 rounded overflow-hidden">
                      <button className="bg-white text-secondary px-4 py-2 hover:bg-coconut transition-colors">-</button>
                      <input type="number" value="1" min="1" className="w-full text-center border-none focus:outline-none text-secondary" />
                      <button className="bg-white text-secondary px-4 py-2 hover:bg-coconut transition-colors">+</button>
                    </div>
                  </div>
                  <div className="mb-6">
                    <label className="block text-secondary font-medium mb-2">Delivery Option</label>
                    <div className="space-y-3">
                      <label className="flex items-center cursor-pointer">
                        <input type="radio" name="delivery" value="delivery" className="custom-radio" defaultChecked />
                        <span className="ml-2 text-secondary">Delivery ($5.99)</span>
                      </label>
                      <label className="flex items-center cursor-pointer">
                        <input type="radio" name="delivery" value="pickup" className="custom-radio" />
                        <span className="ml-2 text-secondary">Pickup (Free)</span>
                      </label>
                    </div>
                  </div>
                  <div className="mb-6">
                    <label className="block text-secondary font-medium mb-2">Special Instructions (Optional)</label>
                    <textarea
                      className="form-input"
                      rows={3}
                      placeholder="Any special requests or dietary concerns?"
                    ></textarea>
                  </div>
                </div>
                <div className="md:w-1/2">
                  <h3 className="heading-font text-2xl font-bold text-secondary mb-6">Your Information</h3>
                  <div className="mb-4">
                    <label className="block text-secondary font-medium mb-2">Full Name</label>
                    <input type="text" className="form-input" placeholder="Your name" />
                  </div>
                  <div className="mb-4">
                    <label className="block text-secondary font-medium mb-2">Email</label>
                    <input type="email" className="form-input" placeholder="Your email" />
                  </div>
                  <div className="mb-4">
                    <label className="block text-secondary font-medium mb-2">Phone</label>
                    <input type="tel" className="form-input" placeholder="Your phone number" />
                  </div>
                  <div className="mb-6">
                    <label className="block text-secondary font-medium mb-2">Delivery Address</label>
                    <input type="text" className="form-input mb-2" placeholder="Street address" />
                    <div className="grid grid-cols-2 gap-2">
                      <input type="text" className="form-input" placeholder="City" />
                      <input type="text" className="form-input" placeholder="Zip code" />
                    </div>
                  </div>
                  <div className="mb-6">
                    <label className="flex items-center cursor-pointer">
                      <input type="checkbox" className="custom-checkbox" />
                      <span className="ml-2 text-secondary">Sign up for our newsletter to receive special offers</span>
                    </label>
                  </div>
                  <button className="w-full bg-accent text-white py-3 rounded-button font-medium hover:bg-opacity-90 transition-colors">
                    Place Order
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-coconut/30">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2">
                <span className="inline-block px-4 py-1 bg-accent text-white rounded-full mb-4 font-medium">
                  Contact Us
                </span>
                <h2 className="heading-font text-3xl md:text-4xl font-bold text-secondary mb-6">
                  Get in Touch
                </h2>
                <p className="text-secondary/80 mb-8">
                  Have questions about our products, delivery options, or custom orders? We'd love to hear from you!
                </p>
                <div className="mb-8">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 flex items-center justify-center bg-secondary rounded-full mr-4">
                      <MapPin className="text-primary w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-secondary">Our Location</h4>
                      <p className="text-secondary/80">208 E Main St, Lewisville, TX 75057</p>
                    </div>
                  </div>
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 flex items-center justify-center bg-secondary rounded-full mr-4">
                      <Mail className="text-primary w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-secondary">Email</h4>
                      <p className="text-secondary/80">info@pasionmechy.com</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-10 h-10 flex items-center justify-center bg-secondary rounded-full mr-4">
                      <Clock className="text-primary w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-secondary">Hours</h4>
                      <p className="text-secondary/80">Monday - Saturday: 7:00 AM - 3:00 PM</p>
                      <p className="text-secondary/80">Sunday: Closed</p>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-4">
                  <a href="#" className="w-10 h-10 flex items-center justify-center bg-secondary text-primary rounded-full hover:bg-accent transition-colors">
                    <i className="ri-facebook-fill"></i>
                  </a>
                  <a href="#" className="w-10 h-10 flex items-center justify-center bg-secondary text-primary rounded-full hover:bg-accent transition-colors">
                    <i className="ri-instagram-line"></i>
                  </a>
                  <a href="#" className="w-10 h-10 flex items-center justify-center bg-secondary text-primary rounded-full hover:bg-accent transition-colors">
                    <i className="ri-twitter-x-line"></i>
                  </a>
                  <a href="#" className="w-10 h-10 flex items-center justify-center bg-secondary text-primary rounded-full hover:bg-accent transition-colors">
                    <i className="ri-whatsapp-line"></i>
                  </a>
                </div>
              </div>
              <div className="md:w-1/2">
                <div className="bg-primary p-6 rounded-lg shadow-md">
                  <h3 className="heading-font text-2xl font-bold text-secondary mb-6">Send Us a Message</h3>
                  <form>
                    <div className="mb-4">
                      <label className="block text-secondary font-medium mb-2">Your Name</label>
                      <input type="text" className="form-input" placeholder="Enter your name" />
                    </div>
                    <div className="mb-4">
                      <label className="block text-secondary font-medium mb-2">Email Address</label>
                      <input type="email" className="form-input" placeholder="Enter your email" />
                    </div>
                    <div className="mb-4">
                      <label className="block text-secondary font-medium mb-2">Subject</label>
                      <input type="text" className="form-input" placeholder="What is this regarding?" />
                    </div>
                    <div className="mb-6">
                      <label className="block text-secondary font-medium mb-2">Message</label>
                      <textarea className="form-input" rows={5} placeholder="Your message"></textarea>
                    </div>
                    <button type="submit" className="w-full bg-accent text-white py-3 rounded-button font-medium hover:bg-opacity-90 transition-colors">
                      Send Message
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}