import { useEffect, useState } from 'react';
import { getOrders } from '../lib/stripe';

export function Success() {
  const [loading, setLoading] = useState(true);
  const [order, setOrder] = useState<any>(null);

  useEffect(() => {
    async function loadLatestOrder() {
      try {
        const orders = await getOrders();
        if (orders && orders.length > 0) {
          setOrder(orders[0]); // Get the most recent order
        }
      } catch (error) {
        console.error('Error loading order:', error);
      } finally {
        setLoading(false);
      }
    }

    loadLatestOrder();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Loading...</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
            <svg
              className="h-6 w-6 text-green-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-bold mb-4">Thank you for your purchase!</h2>
          {order && (
            <div className="text-left mt-6 border-t pt-4">
              <h3 className="font-semibold mb-2">Order Details:</h3>
              <p className="text-gray-600">
                Order ID: {order.order_id}
              </p>
              <p className="text-gray-600">
                Amount: {(order.amount_total / 100).toLocaleString('en-US', {
                  style: 'currency',
                  currency: order.currency,
                })}
              </p>
              <p className="text-gray-600">
                Status: {order.order_status}
              </p>
            </div>
          )}
          <div className="mt-6">
            <a
              href="/"
              className="text-blue-600 hover:text-blue-500 font-medium"
            >
              Return to Home
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}