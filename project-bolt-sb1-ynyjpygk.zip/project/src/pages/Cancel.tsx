export function Cancel() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4">
            <svg
              className="h-6 w-6 text-red-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-bold mb-4">Purchase Cancelled</h2>
          <p className="text-gray-600 mb-6">
            Your purchase has been cancelled. No charges were made.
          </p>
          <a
            href="/"
            className="text-blue-600 hover:text-blue-500 font-medium"
          >
            Return to Home
          </a>
        </div>
      </div>
    </div>
  );
}