import { useState } from 'react';
import { createCheckoutSession } from '../lib/stripe';
import type { ProductId } from '../stripe-config';

interface ProductCardProps {
  productId: ProductId;
  name: string;
  description: string;
  price: string;
  priceId: string;
  mode: 'payment' | 'subscription';
  isBundle?: boolean;
}

export function ProductCard({ productId, name, description, price, priceId, mode, isBundle }: ProductCardProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handlePurchase = async () => {
    try {
      setIsLoading(true);
      await createCheckoutSession(priceId, mode);
    } catch (error) {
      console.error('Failed to create checkout session:', error);
      alert('Failed to start checkout process. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isBundle) {
    return (
      <div className="bg-[#F5F8F2] rounded-lg p-8 text-center h-full flex flex-col justify-center relative">
        <div className="absolute -top-4 -right-4 bg-accent text-white px-4 py-2 rounded-full z-10 shadow-lg">
          <span className="font-bold">Special Offer</span>
        </div>
        <div className="max-w-xl mx-auto">
          <div className="inline-block px-6 py-2 bg-accent text-white rounded-full mb-4 font-bold">
            <i className="ri-gift-line mr-2"></i> Perfect Pair Bundle
          </div>
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="relative">
              <img src="https://static.readdy.ai/image/dd5aa4e36336218ce6e50b5d124c3431/86ecb6196993fd233eb1aca072cfeec2.png" alt="Perfect Pair Bundle" className="w-full h-48 object-cover rounded-lg" />
              <div className="absolute bottom-2 right-2 bg-accent text-white text-xs px-2 py-1 rounded-full">1 lb</div>
            </div>
            <div className="relative">
              <img src="https://static.readdy.ai/image/dd5aa4e36336218ce6e50b5d124c3431/86ecb6196993fd233eb1aca072cfeec2.png" alt="Perfect Pair Bundle" className="w-full h-48 object-cover rounded-lg" />
              <div className="absolute bottom-2 right-2 bg-accent text-white text-xs px-2 py-1 rounded-full">1 lb</div>
            </div>
          </div>
          <p className="text-secondary/80 mb-6">Get two desserts and save! Perfect for sharing or gifting.</p>
          <div className="flex flex-col items-center gap-2 mb-6">
            <div className="flex items-center gap-4">
              <span className="text-3xl font-bold text-accent">{price}</span>
              <span className="text-lg text-secondary/60 line-through">$51.98</span>
              <span className="bg-accent text-white text-sm px-3 py-1 rounded-full">Save $6.98</span>
            </div>
            <div className="flex items-center gap-2 text-accent">
              <i className="ri-truck-line"></i>
              <span className="font-medium">Free Shipping Included</span>
            </div>
          </div>
          <button
            onClick={handlePurchase}
            disabled={isLoading}
            className="bg-secondary text-primary px-8 py-3 rounded-button hover:bg-opacity-90 transition-colors whitespace-nowrap text-lg inline-flex items-center"
          >
            {isLoading ? (
              'Processing...'
            ) : (
              <>
                <i className="ri-shopping-cart-line mr-2"></i> Add Bundle to Cart
              </>
            )}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="absolute -top-4 -right-4 bg-accent text-white px-4 py-2 rounded-full z-10 shadow-lg">
        <span className="font-bold">Best Seller</span>
      </div>
      <div className="product-card bg-primary rounded-lg overflow-hidden shadow-md transition-all duration-300 h-full">
        <div className="h-[20rem] overflow-hidden">
          <img
            src="https://static.readdy.ai/image/dd5aa4e36336218ce6e50b5d124c3431/c89700183cbcd8014abe60091858ab6d.png"
            alt={name}
            className="w-full h-full object-contain object-bottom scale-125 translate-y-12"
          />
        </div>
        <div className="p-6">
          <h3 className="heading-font text-xl font-bold text-secondary mb-3">{name}</h3>
          <p className="text-secondary/80 mb-4">{description}</p>
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="px-3 py-1 bg-coconut text-secondary/80 text-sm rounded-full">Fresh Coconut</span>
            <span className="px-3 py-1 bg-coconut text-secondary/80 text-sm rounded-full">Natural Ingredients</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-accent font-bold text-xl">{price}</span>
            <button
              onClick={handlePurchase}
              disabled={isLoading}
              className="bg-accent text-white px-6 py-2 rounded-button hover:bg-opacity-90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Processing...' : 'Buy Now'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}