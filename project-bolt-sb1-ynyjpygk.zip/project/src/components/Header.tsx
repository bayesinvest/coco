import { useState } from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-primary shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="logo-font text-secondary text-3xl">
          Pasión Mechy
        </Link>
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#home" className="nav-link text-secondary hover:text-accent font-medium transition-colors">
            Home
          </a>
          <a href="#story" className="nav-link text-secondary hover:text-accent font-medium transition-colors">
            Our Story
          </a>
          <a href="#products" className="nav-link text-secondary hover:text-accent font-medium transition-colors">
            Products
          </a>
          <a href="#order" className="nav-link text-secondary hover:text-accent font-medium transition-colors">
            Order Now
          </a>
          <a href="#contact" className="nav-link text-secondary hover:text-accent font-medium transition-colors">
            Contact
          </a>
        </nav>
        <div className="flex items-center space-x-4">
          <a href="#order" className="hidden md:block bg-accent text-white px-6 py-2 rounded-button font-medium hover:bg-opacity-90 transition-colors">
            Order Now
          </a>
          <button
            className="md:hidden w-10 h-10 flex items-center justify-center text-secondary"
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <i className="ri-menu-line ri-xl"></i>
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-secondary z-50 flex flex-col items-center justify-center">
          <button
            className="absolute top-6 right-6 text-primary"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X size={32} />
          </button>
          <nav className="flex flex-col items-center space-y-8">
            <a
              href="#home"
              className="text-primary text-2xl font-medium hover:text-accent transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </a>
            <a
              href="#story"
              className="text-primary text-2xl font-medium hover:text-accent transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Our Story
            </a>
            <a
              href="#products"
              className="text-primary text-2xl font-medium hover:text-accent transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Products
            </a>
            <a
              href="#order"
              className="text-primary text-2xl font-medium hover:text-accent transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Order Now
            </a>
            <a
              href="#contact"
              className="text-primary text-2xl font-medium hover:text-accent transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </a>
          </nav>
          <div className="mt-12 flex space-x-6">
            <a href="#" className="w-12 h-12 flex items-center justify-center bg-primary text-secondary rounded-full hover:bg-accent hover:text-primary transition-colors">
              <i className="ri-facebook-fill ri-xl"></i>
            </a>
            <a href="#" className="w-12 h-12 flex items-center justify-center bg-primary text-secondary rounded-full hover:bg-accent hover:text-primary transition-colors">
              <i className="ri-instagram-line ri-xl"></i>
            </a>
            <a href="#" className="w-12 h-12 flex items-center justify-center bg-primary text-secondary rounded-full hover:bg-accent hover:text-primary transition-colors">
              <i className="ri-twitter-x-line ri-xl"></i>
            </a>
            <a href="#" className="w-12 h-12 flex items-center justify-center bg-primary text-secondary rounded-full hover:bg-accent hover:text-primary transition-colors">
              <i className="ri-whatsapp-line ri-xl"></i>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}