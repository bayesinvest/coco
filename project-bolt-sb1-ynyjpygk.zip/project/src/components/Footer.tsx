export function Footer() {
  return (
    <footer className="bg-coconut pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div>
            <a href="#" className="logo-font text-secondary text-3xl mb-4 inline-block">
              Pasión Mechy
            </a>
          </div>
          <div>
            <h4 className="font-bold text-secondary text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-secondary/80 hover:text-accent transition-colors">Home</a></li>
              <li><a href="#story" className="text-secondary/80 hover:text-accent transition-colors">Our Story</a></li>
              <li><a href="#products" className="text-secondary/80 hover:text-accent transition-colors">Products</a></li>
              <li><a href="#order" className="text-secondary/80 hover:text-accent transition-colors">Order Now</a></li>
              <li><a href="#contact" className="text-secondary/80 hover:text-accent transition-colors">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-secondary text-lg mb-4">Contact Info</h4>
            <ul className="space-y-2">
              <li className="text-secondary/80">208 E Main St, Lewisville, TX 75057</li>
              <li className="text-secondary/80">paum.photography@gmail.com</li>
              <li className="text-secondary/80">Monday - Saturday: 7:00 AM - 3:00 PM</li>
              <li className="text-secondary/80">Sunday: Closed</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-secondary text-lg mb-4">We Accept</h4>
            <div className="flex flex-wrap gap-3">
              <div className="w-12 h-8 flex items-center justify-center bg-white rounded shadow-sm">
                <i className="ri-visa-fill text-blue-700 ri-lg"></i>
              </div>
              <div className="w-12 h-8 flex items-center justify-center bg-white rounded shadow-sm">
                <i className="ri-mastercard-fill text-orange-600 ri-lg"></i>
              </div>
              <div className="w-12 h-8 flex items-center justify-center bg-white rounded shadow-sm">
                <i className="ri-paypal-fill text-blue-600 ri-lg"></i>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-secondary/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-secondary/70 text-sm mb-4 md:mb-0">&copy; 2025 Pasión Mechy. All rights reserved.</p>
            <div className="flex space-x-6">
              <a href="#" className="text-secondary/70 text-sm hover:text-accent transition-colors">Privacy Policy</a>
              <a href="#" className="text-secondary/70 text-sm hover:text-accent transition-colors">Terms of Service</a>
              <a href="#" className="text-secondary/70 text-sm hover:text-accent transition-colors">Shipping Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}