export const products = {
  'dulce-de-coco-bundle': {
    id: 'prod_SJqbVTP2X8waNW',
    priceId: 'price_1RPCtqD1t89I8Gs4Q2ZJQv93',
    name: 'Dulce de coco Bundle',
    description: 'Dulce de coco Bundle',
    price: '$45.00',
    mode: 'payment',
  },
  'dulce-de-coco': {
    id: 'prod_SJqaMyXANi35e9',
    priceId: 'price_1RPCstD1t89I8Gs4bFkT9ZAD',
    name: 'Dulce de coco',
    description: 'Dulce de coco',
    price: '$24.99',
    mode: 'payment',
  },
} as const;

export type ProductId = keyof typeof products;