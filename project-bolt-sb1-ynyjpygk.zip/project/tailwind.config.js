/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#FDF5E6',
        secondary: '#6B3E24',
        accent: '#7C9A4B',
        coconut: '#F5E2C4',
      },
      borderRadius: {
        'none': '0px',
        'sm': '4px',
        DEFAULT: '8px',
        'md': '12px',
        'lg': '16px',
        'xl': '20px',
        '2xl': '24px',
        '3xl': '32px',
        'full': '9999px',
        'button': '8px',
      },
      boxShadow: {
        'card': '0 10px 25px rgba(107, 62, 36, 0.1)',
      },
    },
  },
  plugins: [],
};